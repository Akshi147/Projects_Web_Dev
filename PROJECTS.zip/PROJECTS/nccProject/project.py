import mysql.connector as mysql

con = mysql.connect(host="localhost", port="3306", user="root", password="root")
cursorObj = con.cursor(buffered=True)


def setupProject():
    print("\nSetting up NCC Cadet project...")
    cursorObj.execute("SHOW DATABASES")
    for x in cursorObj:
        if x[0] == "garima_ncc":
            print("Database exists ->", x[0])
            cursorObj.execute("USE garima_ncc")
            con.commit()
            break
        else:
            print("Creating project database...")
            cursorObj.execute("CREATE DATABASE garima_ncc")
            cursorObj.execute("USE garima_ncc")
            createTables()
            con.commit()


def createTables():
    print("Creating project tables...")
    cursorObj.execute(
        "CREATE TABLE STUDENTS (roll INT, name VARCHAR(255), class VARCHAR(255), section VARCHAR(255), age INT, city VARCHAR(255))"
    )
    cursorObj.execute(
        "CREATE TABLE TEACHERS (id INT, name VARCHAR(255), subject VARCHAR(255), age INT, city VARCHAR(255))"
    )
    cursorObj.execute(
        "CREATE TABLE EVENTS (id INT, name VARCHAR(255), type VARCHAR(255), remaining_student INT, budget INT, location VARCHAR(255), coordinator VARCHAR(255), travel_mode VARCHAR(255))"
    )
    cursorObj.execute(
        "CREATE TABLE ACTIVE_EVENTS (event_id INT, student_roll INT, teacher_id INT)"
    )
    con.commit()


def main_menu():
    while 1:
        print("\nWelcome to the NCC Cadet System")
        print("**************************************")
        print("1. Admin Section")
        print("2. Student Section")
        print("3. Teacher Section")
        print("4. Event Section")
        print("5. Exit the project")

        user_opt = input(str("\nEnter option: "))

        if user_opt == "1":
            admin_section()
        elif user_opt == "2":
            student_section()
        elif user_opt == "3":
            teacher_section()
        elif user_opt == "4":
            event_section()
        elif user_opt == "5":
            exit()
        else:
            print("\nPlease enter valid option...")


def admin_section():
    while 1:
        print("\nAdmin Menu")
        print("**************************************")
        print("1. Add new Student")
        print("2. Update existing Student")
        print("3. Delete existing Student")
        print("4. Add new Teacher")
        print("5. Update existing Teacher")
        print("6. Delete existing Teacher")
        print("7. Add new Event")
        print("8. Update existing Event")
        print("9. Delete existing Event")
        print("0. Logout")

        user_opt = input(str("\nEnter option: "))

        if user_opt == "1":
            create_student()
        elif user_opt == "2":
            update_student()
        elif user_opt == "3":
            delete_student()
        elif user_opt == "4":
            create_teacher()
        elif user_opt == "5":
            update_teacher()
        elif user_opt == "6":
            delete_teacher()
        elif user_opt == "7":
            create_event()
        elif user_opt == "8":
            update_event()
        elif user_opt == "9":
            delete_event()
        elif user_opt == "0":
            main_menu()
        else:
            print("\nPlease enter valid option...")


def student_section():
    while 1:
        print("\nStudent Menu")
        print("**************************************")
        print("1. List of all students")
        print("2. Participate in event")
        print("3. Student event participation list")
        print("4. Back to Main menu")

        user_opt = input(str("\nEnter option: "))

        if user_opt == "1":
            display_students()
        elif user_opt == "2":
            apply_event_student()
        elif user_opt == "3":
            student_event_list()
        elif user_opt == "4":
            main_menu()
        else:
            print("\nPlease enter valid option...")


def teacher_section():
    while 1:
        print("\nTeacher Menu")
        print("**************************************")
        print("1. List of all teachers")
        print("2. Back to Main menu")

        user_opt = input(str("\nEnter option: "))

        if user_opt == "1":
            display_teachers()
        elif user_opt == "2":
            main_menu()
        else:
            print("\nPlease enter valid option...")


def event_section():
    while 1:
        print("\nEvent Menu")
        print("**************************************")
        print("1. List of all events")
        print("2. Back to Main menu")

        user_opt = input(str("\nEnter option: "))

        if user_opt == "1":
            display_events()
        elif user_opt == "2":
            main_menu()
        else:
            print("\nPlease enter valid option...")


def create_student():
    print("\nAdd new Student")
    print("**************************************")

    name = input(str("Enter name: "))
    classname = input(str("Enter class: "))
    section = input(str("Enter section: "))
    roll = input(str("Enter roll: "))
    age = input(str("Enter age: "))
    city = input(str("Enter city: "))

    query_val = (roll, name, classname, section, age, city)
    cursorObj.execute("INSERT INTO STUDENTS VALUES (%s,%s,%s,%s,%s,%s)", query_val)
    con.commit()
    print("\nStudent added into the database...")


def update_student():
    print("\nUpdate existing Student")
    print("**************************************")

    roll = input(str("Enter the roll number of student: "))

    query_val = (roll,)
    query = "SELECT * FROM STUDENTS WHERE ROLL=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nExisting student data from database...")
        for row in cursorObj:
            print("\nStudent roll     -> ", row[0])
            print("Student name     -> ", row[1])
            print("Student class    -> ", row[2])
            print("Student section  -> ", row[3])
            print("Student age      -> ", row[4])
            print("Student city     -> ", row[5])

        name = input(str("\nEnter name: "))
        classname = input(str("Enter class: "))
        section = input(str("Enter section: "))
        age = input(str("Enter age: "))
        city = input(str("Enter city: "))

        query_val = (name, classname, section, age, city, roll)
        query = "UPDATE STUDENTS SET NAME = %s, CLASS = %s, SECTION = %s , AGE = %s, CITY = %s WHERE ROLL = %s;"
        cursorObj.execute(query, query_val)
        con.commit()

        print("\nStudent data updated into database...")

    else:
        print("\nNo student found with entered roll number...")


def delete_student():
    print("\nDelete existing Student")
    print("**************************************")

    roll = input(str("Enter the roll number of student: "))

    query_val = (roll,)
    query = "SELECT * FROM STUDENTS WHERE ROLL=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nStudent data from database...")
        for row in cursorObj:
            print("\nStudent roll     -> ", row[0])
            print("Student name     -> ", row[1])
            print("Student class    -> ", row[2])
            print("Student section  -> ", row[3])
            print("Student age      -> ", row[4])
            print("Student city     -> ", row[5])

        user_opt = input(
            str("\nPress 'D' to delete the student, 'M' to return to previous menu: ")
        )

        if user_opt == "D" or user_opt == "d":
            query_val = (roll,)
            query = "DELETE FROM STUDENTS WHERE ROLL = %s;"
            cursorObj.execute(query, query_val)
            con.commit()
            print("\nStudent deleted from database...")
        elif user_opt == "M" or user_opt == "m":
            admin_section()
        else:
            print("\nPlease enter valid option...")

    else:
        print("\nNo student found with entered roll number...")


def create_teacher():
    print("\nAdd new Teacher")
    print("**************************************")

    name = input(str("Enter name: "))
    subject = input(str("Enter subject: "))
    id = input(str("Enter ID: "))
    age = input(str("Enter age: "))
    city = input(str("Enter city: "))

    query_val = (id, name, subject, age, city)
    cursorObj.execute("INSERT INTO TEACHERS VALUES (%s,%s,%s,%s,%s)", query_val)
    con.commit()
    print("\nTeacher added into the database...")


def update_teacher():
    print("\nUpdate existing Teacher")
    print("**************************************")

    id = input(str("Enter the ID of teacher: "))

    query_val = (id,)
    query = "SELECT * FROM TEACHERS WHERE ID=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nExisting teacher data from database...")
        for row in cursorObj:
            print("\nTeacher's ID         -> ", row[0])
            print("Teacher's Name       -> ", row[1])
            print("Teacher's Subject    -> ", row[2])
            print("Teacher's Age        -> ", row[3])
            print("Teacher's City       -> ", row[4])
            print("**************************************")

        name = input(str("\nEnter name: "))
        subject = input(str("Enter subject: "))
        age = input(str("Enter age: "))
        city = input(str("Enter city: "))

        query_val = (name, subject, age, city, id)
        query = "UPDATE TEACHERS SET NAME = %s, SUBJECT = %s, AGE = %s, CITY = %s WHERE ID = %s;"
        cursorObj.execute(query, query_val)
        con.commit()

        print("\nTeacher data updated into database...")

    else:
        print("\nNo teacher found with entered ID...")


def delete_teacher():
    print("\nDelete existing Teacher")
    print("**************************************")

    id = input(str("Enter the ID of teacher: "))

    query_val = (id,)
    query = "SELECT * FROM TEACHERS WHERE ID=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nExisting teacher data from database...")
        for row in cursorObj:
            print("\nTeacher's ID         -> ", row[0])
            print("Teacher's Name       -> ", row[1])
            print("Teacher's Subject    -> ", row[2])
            print("Teacher's Age        -> ", row[3])
            print("Teacher's City       -> ", row[4])
            print("**************************************")

        user_opt = input(
            str("\nPress 'D' to delete the teacher, 'M' to return to previous menu: ")
        )

        if user_opt == "D" or user_opt == "d":
            query_val = (id,)
            query = "DELETE FROM TEACHERS WHERE ID = %s;"
            cursorObj.execute(query, query_val)
            con.commit()
            print("\nTeacher deleted from database...")
        elif user_opt == "M" or user_opt == "m":
            admin_section()
        else:
            print("\nPlease enter valid option...")

    else:
        print("\nNo teacher found with entered ID...")


def create_event():
    print("\nAdd new Event")
    print("**************************************")

    id = input(str("Enter ID: "))
    name = input(str("Enter Name: "))
    type = input(str("Enter Type: "))
    count = input(str("Enter Student Count: "))
    budget = input(str("Enter Budget: "))
    location = input(str("Enter Location: "))
    coordinator = input(str("Enter Coordinator Teacher: "))
    travel = input(str("Enter Travel Mode: "))

    query_val = (id, name, type, count, budget, location, coordinator, travel)
    cursorObj.execute("INSERT INTO EVENTS VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", query_val)
    con.commit()
    print("\nEvent added into the database...")


def update_event():
    print("\nUpdate existing Event")
    print("**************************************")

    id = input(str("Enter the ID of event: "))

    query_val = (id,)
    query = "SELECT * FROM EVENTS WHERE ID=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nExisting event data from database...")
        for row in cursorObj:
            print("Event ID                 -> ", row[0])
            print("Event name               -> ", row[1])
            print("Event type               -> ", row[2])
            print("Event remaining student  -> ", row[3])
            print("Event budget             -> ", row[4])
            print("Event location           -> ", row[5])
            print("Event coordinator        -> ", row[6])
            print("Event travel mode        -> ", row[7])
            print("**************************************")

        name = input(str("Enter Name: "))
        type = input(str("Enter Type: "))
        count = input(str("Enter Student Count: "))
        budget = input(str("Enter Budget: "))
        location = input(str("Enter Location: "))
        coordinator = input(str("Enter Coordinator Teacher: "))
        travel = input(str("Enter Travel Mode: "))

        query_val = (name, type, count, budget, location, coordinator, travel, id)
        query = "UPDATE EVENTS SET NAME = %s, TYPE = %s, REMAINING_STUDENT = %s , BUDGET = %s, LOCATION = %s, COORDINATOR = %s, TRAVEL_MODE = %s WHERE ID = %s;"
        cursorObj.execute(query, query_val)
        con.commit()

        print("\nEvent data updated into database...")

    else:
        print("\nNo event found with entered ID...")


def delete_event():
    print("\nDelete existing Event")
    print("**************************************")

    id = input(str("Enter the ID of event: "))

    query_val = (id,)
    query = "SELECT * FROM EVENTS WHERE ID=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nEvent data from database...")
        for row in cursorObj:
            print("Event ID                 -> ", row[0])
            print("Event name               -> ", row[1])
            print("Event type               -> ", row[2])
            print("Event remaining student  -> ", row[3])
            print("Event budget             -> ", row[4])
            print("Event location           -> ", row[5])
            print("Event coordinator        -> ", row[6])
            print("Event travel mode        -> ", row[7])
            print("**************************************")

        user_opt = input(
            str("\nPress 'D' to delete the event, 'M' to return to previous menu: ")
        )

        if user_opt == "D" or user_opt == "d":
            query_val = (id,)
            query = "DELETE FROM EVENTS WHERE ID = %s;"
            cursorObj.execute(query, query_val)
            con.commit()
            print("\nEvent deleted from database...")
        elif user_opt == "M" or user_opt == "m":
            admin_section()
        else:
            print("\nPlease enter valid option...")

    else:
        print("\nNo event found with entered ID...")


def display_students():
    print("\nList of all students")
    print("**************************************")

    query = "SELECT * FROM STUDENTS"
    cursorObj.execute(query)
    for row in cursorObj:
        print("Student roll     -> ", row[0])
        print("Student name     -> ", row[1])
        print("Student class    -> ", row[2])
        print("Student section  -> ", row[3])
        print("Student age      -> ", row[4])
        print("Student city     -> ", row[5])
        print("**************************************")

    user_opt = input(
        str("\nPress 'M' to return to previous menu, 'C' to close the project: ")
    )

    if user_opt == "M" or user_opt == "m":
        student_section()
    elif user_opt == "C" or user_opt == "c":
        exit()
    else:
        print("\nPlease enter valid option...")


def display_teachers():
    print("\nList of all teachers")
    print("**************************************")

    query = "SELECT * FROM TEACHERS"
    cursorObj.execute(query)
    for row in cursorObj:
        print("Teacher's ID         -> ", row[0])
        print("Teacher's Name       -> ", row[1])
        print("Teacher's Subject    -> ", row[2])
        print("Teacher's Age        -> ", row[3])
        print("Teacher's City       -> ", row[4])
        print("**************************************")

    user_opt = input(
        str("\nPress 'M' to return to previous menu, 'C' to close the project: ")
    )

    if user_opt == "M" or user_opt == "m":
        teacher_section()
    elif user_opt == "C" or user_opt == "c":
        exit()
    else:
        print("\nPlease enter valid option...")


def display_events():
    print("\nList of all events")
    print("**************************************")

    query = "SELECT * FROM EVENTS"
    cursorObj.execute(query)
    for row in cursorObj:
        print("Event ID                 -> ", row[0])
        print("Event name               -> ", row[1])
        print("Event type               -> ", row[2])
        print("Event remaining student  -> ", row[3])
        print("Event budget             -> ", row[4])
        print("Event location           -> ", row[5])
        print("Event coordinator        -> ", row[6])
        print("Event travel mode        -> ", row[7])
        print("**************************************")

    user_opt = input(
        str("\nPress 'M' to return to previous menu, 'C' to close the project: ")
    )

    if user_opt == "M" or user_opt == "m":
        event_section()
    elif user_opt == "C" or user_opt == "c":
        exit()
    else:
        print("\nPlease enter valid option...")


def apply_event_student():
    print("\nParticipate in Event")
    print("**************************************")

    roll = input(str("Enter your roll number: "))
    id = input(str("Enter event ID: "))
    teacherid = 0

    query_val = (id,)
    query = "SELECT * FROM EVENTS WHERE ID=%s"
    cursorObj.execute(query, query_val)

    if cursorObj.rowcount > 0:
        print("\nEvent data from database...")
        for row in cursorObj:
            print("\nEvent ID                 -> ", row[0])
            print("Event name               -> ", row[1])
            print("Event type               -> ", row[2])
            print("Event remaining student  -> ", row[3])
            print("Event budget             -> ", row[4])
            print("Event location           -> ", row[5])
            print("Event coordinator        -> ", row[6])
            print("Event travel mode        -> ", row[7])
            print("**************************************")

        user_opt = input(
            str(
                "\nPress 'Y' to participate in the event, 'C' to return to previous menu: "
            )
        )

        if user_opt == "Y" or user_opt == "y":
            query_val = (id, roll, teacherid)
            query = "INSERT INTO ACTIVE_EVENTS VALUES (%s,%s,%s)"
            cursorObj.execute(query, query_val)

            query2 = "UPDATE EVENTS SET REMAINING_STUDENT = REMAINING_STUDENT - 1 WHERE ID = %s AND REMAINING_STUDENT > 0;"
            query_val2 = (id,)
            cursorObj.execute(query2, query_val2)

            con.commit()
            print("\nParticipated in the event...")
        elif user_opt == "M" or user_opt == "m":
            admin_section()
        else:
            print("\nPlease enter valid option...")

    else:
        print("\nNo event found with entered ID...")


def student_event_list():
    print("\nStudent Event Participation List")
    print("**************************************")

    query = "SELECT STUDENTS.roll, STUDENTS.name, STUDENTS.class, STUDENTS.section, EVENTS.name, EVENTS.type, EVENTS.location FROM STUDENTS, EVENTS, ACTIVE_EVENTS WHERE STUDENTS.roll = ACTIVE_EVENTS.student_roll AND EVENTS.id = ACTIVE_EVENTS.event_id;"

    cursorObj.execute(query)
    for row in cursorObj:
        print("Student roll     -> ", row[0])
        print("Student name     -> ", row[1])
        print("Student class    -> ", row[2])
        print("Student section  -> ", row[3])
        print("Event name       -> ", row[4])
        print("Event type       -> ", row[5])
        print("Event location   -> ", row[6])
        print("**************************************")

    user_opt = input(
        str("\nPress 'M' to return to previous menu, 'C' to close the project: ")
    )

    if user_opt == "M" or user_opt == "m":
        student_section()
    elif user_opt == "C" or user_opt == "c":
        exit()
    else:
        print("\nPlease enter valid option...")


def main():
    setupProject()
    main_menu()


main()
