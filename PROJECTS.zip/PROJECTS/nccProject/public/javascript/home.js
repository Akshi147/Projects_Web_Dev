for (var i=0;i<4;i++)
{
    document.querySelectorAll(".btn")[i].addEventListener("click",function()
                                                                {
                                                                    var audio=new Audio("../sounds/button_sound.mp3");
                                                                    audio.play();
                                                                });
}

